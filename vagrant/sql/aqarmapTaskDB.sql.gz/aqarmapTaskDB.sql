-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 15, 2019 at 05:11 AM
-- Server version: 5.7.26-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aqarmapTaskDB`
--

-- --------------------------------------------------------

--
-- Table structure for table `Articles`
--

CREATE TABLE `Articles` (
  `id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `content` varchar(10000) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Articles`
--

INSERT INTO `Articles` (`id`, `title`, `content`, `created_by`, `created_date`) VALUES
(1, 'Create new blog with PHP and Mysql', 'Create new blog with PHP and Mysql,Create new blog with PHP and Mysql,Create new blog with PHP and MysqlCreate new blog with PHP and MysqlCreate new blog with PHP and MysqlCreate new blog with PHP and MysqlCreate new blog with PHP and Mysql', 2, '2019-07-12 16:06:16'),
(2, 'Create new blog with Node and MongoDB', 'Create new blog with Node and MongoDB,Create new blog with Node and MongoDBCreate new blog with Node and MongoDB,Create new blog with Node and MongoDBCreate new blog with Node and MongoDBCreate new blog with Node and MongoDB,', 2, '2019-07-12 16:06:16');

-- --------------------------------------------------------

--
-- Table structure for table `Article_Categories`
--

CREATE TABLE `Article_Categories` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Article_Categories`
--

INSERT INTO `Article_Categories` (`id`, `article_id`, `category_id`) VALUES
(6, 1, 3),
(7, 1, 1),
(8, 2, 4),
(9, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `Article_Comments`
--

CREATE TABLE `Article_Comments` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Article_Comments`
--

INSERT INTO `Article_Comments` (`id`, `article_id`, `comment`, `created_by`, `created_date`) VALUES
(1, 1, 'Nice article', 1, '2019-07-12 16:11:56');

-- --------------------------------------------------------

--
-- Table structure for table `Categories`
--

CREATE TABLE `Categories` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Categories`
--

INSERT INTO `Categories` (`id`, `name`) VALUES
(2, 'java'),
(4, 'node'),
(5, 'nosql'),
(3, 'php'),
(1, 'sql');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `username` varchar(225) NOT NULL,
  `password` varchar(225) DEFAULT NULL,
  `role` enum('user','admin') NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `username`, `password`, `role`) VALUES
(1, 'ahmed@test.com', '7f10d070a92320bfa56bea4aeb5ec3bcbb1c6f58', 'user'),
(2, 'admin@test.com', 'c9e4da942c104238c539d4dae066eadaeeea2485', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `Articles`
--
ALTER TABLE `Articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_Articles_admin_who_created_article_idx` (`created_by`);

--
-- Indexes for table `Article_Categories`
--
ALTER TABLE `Article_Categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_A_C_article_which_categorized_idx` (`article_id`),
  ADD KEY `fk_A_C_category_which_article_categorized_under_idx` (`category_id`);

--
-- Indexes for table `Article_Comments`
--
ALTER TABLE `Article_Comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_A_C_user_who_create_comment_idx` (`created_by`),
  ADD KEY `fk_A_C_article_which_comment_for_idx` (`article_id`);

--
-- Indexes for table `Categories`
--
ALTER TABLE `Categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name_UNIQUE` (`name`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username_UNIQUE` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `Articles`
--
ALTER TABLE `Articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `Article_Categories`
--
ALTER TABLE `Article_Categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `Article_Comments`
--
ALTER TABLE `Article_Comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `Categories`
--
ALTER TABLE `Categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `Articles`
--
ALTER TABLE `Articles`
  ADD CONSTRAINT `fk_Articles_admin_who_created_article` FOREIGN KEY (`created_by`) REFERENCES `Users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Article_Categories`
--
ALTER TABLE `Article_Categories`
  ADD CONSTRAINT `fk_A_C_article_which_categorized` FOREIGN KEY (`article_id`) REFERENCES `Articles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_A_C_category_which_article_categorized_under` FOREIGN KEY (`category_id`) REFERENCES `Categories` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `Article_Comments`
--
ALTER TABLE `Article_Comments`
  ADD CONSTRAINT `fk_A_C_article_which_comment_for` FOREIGN KEY (`article_id`) REFERENCES `Articles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_A_C_user_who_create_comment` FOREIGN KEY (`created_by`) REFERENCES `Users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
